#pragma once

#include "state.h"

state_ptr iddfs(state_ptr root);
