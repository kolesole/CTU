package cz.cvut.fel.agents.pdv.student;

public class ReplyEntries {
}
