#include "utils.h"

int find_string_in_array(const char** array, int length, char* what) {
    for (int i = 0; i < length; i++) {
        if (strcmp(array[i], what) == 0) {
            return i;
        }
    }
    return -1;
}