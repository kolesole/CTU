#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "utils.h"
#include "worker.h"
#include "workers_list.h"

enum place {
    NUZKY, VRTACKA, OHYBACKA, SVARECKA, LAKOVNA, SROUBOVAK, FREZA
};

const char* place_str[7] = {
    [NUZKY] = "nuzky",
    [VRTACKA] = "vrtacka",
    [OHYBACKA] = "ohybacka",
    [SVARECKA] = "svarecka",
    [LAKOVNA] = "lakovna",
    [SROUBOVAK] = "sroubovak",
    [FREZA] = "freza",
};

enum product {
    A, B, C,
};

const char* product_str[3] = {
    [A] = "A",
    [B] = "B",
    [C] = "C",
};

const int processes[3][6] = {
    {NUZKY, VRTACKA, OHYBACKA, SVARECKA, VRTACKA, LAKOVNA},
    {VRTACKA, NUZKY, FREZA, VRTACKA, LAKOVNA, SROUBOVAK},
    {FREZA, VRTACKA, SROUBOVAK, VRTACKA, FREZA, LAKOVNA}
};

int num_of_places[7] = {0};
int ready_places[7] = {0};
int available_works[7] = {0};
int num_of_workers[7] = {0};
int parts[3][6] = {0};
int num_of_est_works[3][6] = {0};

worker_t* workers_head = NULL;
worker_t* workers_tail = NULL;

pthread_mutex_t var_mutex;
pthread_mutex_t work_mutex;
pthread_cond_t work_cond;
pthread_mutex_t stdout_mutex;
pthread_mutex_t workers_list_mutex;

bool eof = false;

int main(int argc, char **argv) {
    if (pthread_mutex_init(&work_mutex, NULL) != 0) {
        fprintf(stderr, "Error: Failed to initialize mutex!\n");
        return 1;
    }

    if (pthread_cond_init(&work_cond, NULL) != 0) {
        fprintf(stderr, "Error: Failed to initialize condition variable!\n");
        pthread_mutex_destroy(&work_mutex);
        return 1;
    }

    if (pthread_mutex_init(&stdout_mutex, NULL) != 0) {
        fprintf(stderr, "Error: Failed to initialize mutex!\n");
        pthread_mutex_destroy(&work_mutex);
        pthread_cond_destroy(&work_cond);
        return 1;
    }

    if (pthread_mutex_init(&workers_list_mutex, NULL) != 0) {
        fprintf(stderr, "Error: Failed to initialize mutex!\n");
        pthread_mutex_destroy(&work_mutex);
        pthread_cond_destroy(&work_cond);
        pthread_mutex_destroy(&stdout_mutex);
        return 1;
    }

    if (pthread_mutex_init(&var_mutex, NULL) != 0) {
        fprintf(stderr, "Error: Failed to initialize mutex!\n");
        pthread_mutex_destroy(&work_mutex);
        pthread_cond_destroy(&work_cond);
        pthread_mutex_destroy(&stdout_mutex);
        pthread_mutex_destroy(&workers_list_mutex);
        return 1;
    }

    char *line = NULL;
    size_t sz = 0;
    while (1) {
        char *cmd, *arg1, *arg2, *arg3, *saveptr;

        if (getline(&line, &sz, stdin) == -1) {
            break; /* Error or EOF */
        }

        cmd = strtok_r(line, " \r\n", &saveptr);
        arg1 = strtok_r(NULL, " \r\n", &saveptr);
        arg2 = strtok_r(NULL, " \r\n", &saveptr);
        arg3 = strtok_r(NULL, " \r\n", &saveptr);

        if (!cmd) {
            continue; /* Empty line */
        }
        else if (strcmp(cmd, "start") == 0 && arg1 && arg2 && !arg3) {
            int place = find_string_in_array(place_str, 7, arg2);
            if (place == -1) {
                fprintf(stderr, "Error: Invalid place!\n");
                continue;
            }
            if (!add_worker(arg1, place)) {
                fprintf(stderr, "Error: Failed to add worker!\n");
                pthread_mutex_destroy(&work_mutex);
                pthread_cond_destroy(&work_cond);
                pthread_mutex_destroy(&stdout_mutex);
                pthread_mutex_destroy(&workers_list_mutex);
                pthread_mutex_destroy(&var_mutex);
                free_list();
                return 1;
            }

            if (pthread_create(&workers_tail->thread, NULL, worker_function, workers_tail) != 0) {
                fprintf(stderr, "Error: Failed to create worker thread!\n");
                pthread_mutex_destroy(&work_mutex);
                pthread_cond_destroy(&work_cond);
                pthread_mutex_destroy(&stdout_mutex);
                pthread_mutex_destroy(&workers_list_mutex);
                pthread_mutex_destroy(&var_mutex);
                free_list();
                return 1;
            }

            pthread_mutex_lock(&var_mutex);
            num_of_workers[place]++;
            pthread_mutex_unlock(&var_mutex);
        }
        else if (strcmp(cmd, "make") == 0 && arg1 && !arg2) {
            int product = find_string_in_array(product_str, 7, arg1);
            if (product == -1) {
                fprintf(stderr, "Error: Invalid product!\n");
                continue;
            }

            pthread_mutex_lock(&var_mutex);
            switch (product) {
                case A:
                    available_works[0]++;
                    num_of_est_works[0][0]++;
                    parts[0][0]++;
                    break;
                case B:
                    available_works[1]++;
                    num_of_est_works[1][0]++;
                    parts[1][0]++;
                    break;
                case C:
                    available_works[6]++;
                    num_of_est_works[2][0]++;
                    parts[2][0]++;
                    break;
                default:
                    break;
            }
            pthread_mutex_unlock(&var_mutex);

            pthread_cond_broadcast(&work_cond);
        }
        else if (strcmp(cmd, "end") == 0 && arg1 && !arg2) {
            worker_t* worker = find_worker(arg1);
            if (worker == NULL) {
                fprintf(stderr, "Error: Failed to find worker named %s\n", arg1);
            } else {
                pthread_mutex_lock(&workers_list_mutex);
                worker->end = true;
                pthread_mutex_unlock(&workers_list_mutex);
                pthread_cond_broadcast(&work_cond);
            }

        }
        else if (strcmp(cmd, "add") == 0 && arg1 && !arg2) {
            int place = find_string_in_array(place_str, 7, arg1);
            if (place == -1) {
                fprintf(stderr, "Error: Invalid place!\n");
                continue;
            }

            pthread_mutex_lock(&var_mutex);
            num_of_places[place]++;
            ready_places[place]++;
            pthread_mutex_unlock(&var_mutex);

            pthread_cond_broadcast(&work_cond);
        }
        else if (strcmp(cmd, "remove") == 0 && arg1 && !arg2) {
            int place = find_string_in_array(place_str, 7, arg1);
            if (place == -1) {
                fprintf(stderr, "Error: Invalid place!\n");
                continue;
            }

            pthread_mutex_lock(&var_mutex);
            num_of_places[place]--;
            ready_places[place]--;
            pthread_mutex_unlock(&var_mutex);
        } else {
            fprintf(stderr, "Invalid command: %s\n", line);
        }
    }
    free(line);

    eof = true;
    pthread_cond_broadcast(&work_cond);

    worker_t* worker = workers_head;
    while (worker) {
        pthread_join(worker->thread, NULL);
        worker_t* tmp_worker = worker;
        worker = worker->next;

        delete_worker(tmp_worker);
    }

    pthread_mutex_destroy(&work_mutex);
    pthread_cond_destroy(&work_cond);
    pthread_mutex_destroy(&stdout_mutex);
    pthread_mutex_destroy(&var_mutex);
    free_list();
    pthread_mutex_destroy(&workers_list_mutex);
    return 0;
}