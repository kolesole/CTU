#pragma once

#include "state.h"

state_ptr bfs(state_ptr root);
