#ifndef UTILS_H
#define UTILS_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

#include "tree_utils.h"

bool read_input(int* N, int* M, int* A, int* B, node_t*** tree);

#endif //UTILS_H
