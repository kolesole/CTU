package cz.cvut.fel.agents.pdv.dsand;

public class TerminateAllMessage extends Message {
}
