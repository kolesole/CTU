package cz.cvut.fel.agents.pdv.student;

import cz.cvut.fel.agents.pdv.dsand.Message;
import cz.cvut.fel.agents.pdv.dsand.Pair;
import cz.cvut.fel.agents.pdv.evaluation.StoreOperationEnums;
import cz.cvut.fel.agents.pdv.raft.RaftProcess;

import java.util.*;
import java.util.function.BiConsumer;

import cz.cvut.fel.agents.pdv.raft.messages.*;

/**
 * Vasim ukolem bude naimplementovat (pravdepodobne nejenom) tuto tridu. Procesy v clusteru pracuji
 * s logy, kde kazdy zanam ma podobu mapy - kazdy zaznam v logu by mel reprezentovat stav
 * distribuovane databaze v danem okamziku.
 *
 * Vasi implementaci budeme testovat v ruznych scenarich (viz evaluation.RaftRun a oficialni
 * zadani). Nasim cilem je, abyste zvladli implementovat jednoduchou distribuovanou key/value
 * databazi s garancemi podle RAFT.
 */
public class ClusterProcess extends RaftProcess<Map<String, String>> {

  enum ProcessState {
    Leader,
    Follower,
    Candidate
  }

  private final List<String> otherProcessesInCluster;

  private ProcessState state;

  private int epoch;

  private int votedForEpoch;

  private int wakeCount;

  private int leaderMessageTime;

  private int votesReceived;

  private final Log log;

  private String leader;

  private final int majority;

  private final int processNetworkDelay;

  private Log waitingRequests;

  private final Database database;

  private int numReceiversLastLogEl;

  private LogElement lastCommittedLogElement;

  public ClusterProcess(String id, Queue<Message> inbox, BiConsumer<String, Message> outbox,
                        List<String> otherProcessesInCluster, int networkDelays) {
    super(id, inbox, outbox);
    this.otherProcessesInCluster = otherProcessesInCluster;
    this.majority = (otherProcessesInCluster.size()) / 2 + 1;

    this.processNetworkDelay = new Random().nextInt(1, otherProcessesInCluster.size() * 2) * (networkDelays + 2);

    this.state = ProcessState.Follower;
    this.leader = null;
    this.leaderMessageTime = 0;
    this.votesReceived = 0;
    this.votedForEpoch = 0;

    this.epoch = 0;
    this.wakeCount = 0;

    this.log = new Log(new ArrayList<LogElement>());
    this.waitingRequests = null;

    database = new Database();
    numReceiversLastLogEl = 0;

    lastCommittedLogElement = null;
  }

  public boolean isLeaderRelevant() {
    return (wakeCount - leaderMessageTime < processNetworkDelay) || (state == ProcessState.Leader);
  }

  @Override
  public Optional<Map<String, String>> getLastSnapshotOfLog() {
    return Optional.of(database.DB);
  }

  @Override
  public String getCurrentLeader() {
    return leader;
  }



  public void handleVoteMessage(VoteMessage vm) {
    if (votedForEpoch < vm.epoch) {
      send(vm.sender, new ReplyVoteMessage());
      votedForEpoch = vm.epoch;
    }
  }

  public void handleReplyVoteMessage(ReplyVoteMessage rvm) {
    votesReceived++;
    if (votesReceived > majority) {
      state = ProcessState.Leader;
      votesReceived = 0;
      leader = getId();
      waitingRequests = new Log(new ArrayList<>());
      lastCommittedLogElement = null;
      numReceiversLastLogEl = 0;
    }
  }

  public void handleAppendEntries(AppendEntries ae) {
    if (ae.epoch >= epoch) {
      epoch = ae.epoch;
      state = ProcessState.Follower;
      leader = ae.sender;
      leaderMessageTime = wakeCount;
      waitingRequests = new Log(new ArrayList<>());
      lastCommittedLogElement = null;
      numReceiversLastLogEl = 0;

      LogElement logEl = ae.committedLogEl;
      if (logEl != null) {
        LogElement lastLogEl = log.getLastLogEl();
        if (lastLogEl != null && lastLogEl.equals(logEl) && !lastLogEl.committed) {
          String op = lastLogEl.operation;
          String key = lastLogEl.key;
          String value = lastLogEl.value;
          if (op.equals("PUT")) {
            database.put(key, value);
          }
          else if (op.equals("APPEND")) {
            database.append(key, value);
          }
        }
      }
    }
  }

  public void handleRequestWhoIsLeader(ClientRequestWhoIsLeader crwil) {
    send(crwil.sender, new ServerResponseLeader(crwil.getRequestId(), leader));
  }

  public void handleRequestWithContent(ClientRequestWithContent<StoreOperationEnums, Pair<String, String>> crwc) {
    if (state != ProcessState.Leader) {
      send(crwc.sender, new ServerResponseLeader(crwc.getRequestId(), leader));
      return;
    }

    IOperation op = crwc.getOperation();
    Pair<String, String> content = crwc.getContent();
    LogElement newLogEl = new LogElement(epoch, crwc.sender, crwc.getRequestId(),
            op, content.getFirst(), content.getSecond());

    LogElement lastLogEl = log.getLastLogEl();

    if (log.contains(newLogEl)) {
      send(newLogEl.clientID, new ServerResponseConfirm(newLogEl.requestID));
      return;
    }

    if (waitingRequests.contains(newLogEl)) return;



    if (log.isLastElCommitted() && waitingRequests.isEmpty()) {
      // LogElement lastLogEl = log.getLastLogEl();
      log.addLogEl(newLogEl);
      // for (String otherProcess : otherProcessesInCluster) {
        // if (otherProcess.equals(getId())) continue;

        //send(otherProcess, new AppendEntriesWithContent(lastLogEl, newLogEl));
      // }
    } else {
      waitingRequests.addLogEl(newLogEl);
    }
  }

  public void handleAppendEntriesWithContent(AppendEntriesWithContent aewc) {
    LogElement newLogEl = aewc.newLogEl;
    LogElement lastLogEl = log.getLastLogEl();

    if (lastLogEl == null && aewc.lastLogEl == null) {
      log.addLogEl(newLogEl);
      send(aewc.sender, new ReplyEntriesWithContent(newLogEl));
    }
    else if (lastLogEl != null && newLogEl != null && lastLogEl.equals(aewc.lastLogEl)) {
      lastLogEl.committed = true;
      log.addLogEl(newLogEl);
      send(aewc.sender, new ReplyEntriesWithContent(newLogEl));
    }
  }

  public void handleReplyEntriesWithContent(ReplyEntriesWithContent rwc) {
    LogElement lastLogEl = log.getLastLogEl();
    LogElement newLogEl = rwc.committedLogEl;

    if (lastLogEl.equals(newLogEl)) {
      numReceiversLastLogEl++;
      if (numReceiversLastLogEl > majority) {
        lastLogEl.committed = true;
        lastCommittedLogElement = lastLogEl;
      }
    }
  }

  @Override
  public void act() {
    wakeCount++;

    while (!inbox.isEmpty()) {
      Message m = inbox.poll();
      if (m instanceof VoteMessage vm) {
        handleVoteMessage(vm);
      }
      else if (m instanceof ReplyVoteMessage rvm) {
        handleReplyVoteMessage(rvm);
      }
      else if (m instanceof AppendEntries ae) {
        handleAppendEntries(ae);
      }
      else if (m instanceof ClientRequestWhoIsLeader crwil) {
        handleRequestWhoIsLeader(crwil);
      }
      else if (m instanceof ClientRequestWithContent) {
        ClientRequestWithContent<StoreOperationEnums, Pair<String, String>> crwc =
                (ClientRequestWithContent<StoreOperationEnums, Pair<String, String>>) m;
        handleRequestWithContent(crwc);
      }
      else if (m instanceof AppendEntriesWithContent aewc) {
        handleAppendEntriesWithContent(aewc);
      }
      else if (m instanceof ReplyEntriesWithContent rwc) {
        handleReplyEntriesWithContent(rwc);
      }
    }

    if (state == ProcessState.Leader) {
      LogElement lastLogEl = log.getLastLogEl();
      LogElement waitingEl = waitingRequests.getFirstLogEl();
      LogElement penultimateLogEl = log.getLogEl(log.getSize() - 2);

      for (String otherProcess : otherProcessesInCluster) {
        if (otherProcess.equals(getId())) continue;

        if (lastLogEl != null && !lastLogEl.committed) {
          send(otherProcess, new AppendEntriesWithContent(penultimateLogEl, lastLogEl));
        }
        else if (waitingEl != null) {
          log.addLogEl(waitingEl);
          waitingRequests.removeFirstLogEl();
          send(otherProcess, new AppendEntriesWithContent(lastLogEl, waitingEl));
        }

        send(otherProcess, new AppendEntries(epoch, lastCommittedLogElement));
      }

      if (lastCommittedLogElement != null) {
        // System.out.println("fdsfsf");
        String op = lastCommittedLogElement.operation;
        String key = lastCommittedLogElement.key;
        String value = lastCommittedLogElement.value;
        String requestID = lastCommittedLogElement.requestID;
        String clientID = lastCommittedLogElement.clientID;

        // System.out.println(op + " " + key + " " + value + " " + requestID + " " + clientID);
        if (op.equals("PUT")) {
          database.put(key, value);
          // System.out.println(key + " " + value + " " + requestID + " " + clientID);
          send(clientID, new ServerResponseConfirm(requestID));
        }
        else if (op.equals("APPEND")) {
          database.append(key, value);
          // System.out.println(key + " " + database.get(key));
          send(clientID, new ServerResponseConfirm(requestID));
        }
        else if (op.equals("GET")) {
          send(clientID, new ServerResponseWithContent<String>(requestID, database.get(key)));
        }
        lastCommittedLogElement = null;
        numReceiversLastLogEl = 0;
      }
    }

    if (!isLeaderRelevant()) {
      if (state != ProcessState.Candidate) {
        state = ProcessState.Candidate;
        epoch++;
        votesReceived = 1;
        votedForEpoch = epoch;
      }

      for (String otherProcess : otherProcessesInCluster) {
        if (otherProcess.equals(getId())) continue;

        send(otherProcess, new VoteMessage(epoch, log.getSize() - 1));
      }
    }
  }
}
