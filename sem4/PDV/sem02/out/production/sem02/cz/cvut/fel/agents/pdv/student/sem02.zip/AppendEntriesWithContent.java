package cz.cvut.fel.agents.pdv.student;

import cz.cvut.fel.agents.pdv.dsand.Message;

public class AppendEntriesWithContent extends Message {
    public LogElement lastLogEl;
    public LogElement newLogEl;

    public AppendEntriesWithContent(LogElement lastLogEl, LogElement newLogEl) {
        this.lastLogEl = lastLogEl;
        this.newLogEl = newLogEl;
    }
}
