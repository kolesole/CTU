import random, time
import numpy as np

import ox

class MCTSBot:
	C = np.sqrt(2)

	def __init__(self, play_as: int, time_limit: float):
		self.play_as = play_as
		self.time_limit = time_limit * 0.9
		self.Q = dict()
		self.action_N = dict()
		self.N = dict()

	def select_action(self, board):
		best_action = None
		best_value = -np.inf
		expanded = False
		for a in board.get_actions():
			cur_action_n = self.action_N.get((board, a), 0)
			if cur_action_n == 0:
				best_action = a
				expanded = True
				break
			cur_value = self.Q.get((board, a)) + self.C * np.sqrt(np.log(cur_action_n) / self.N.get(board))
			if cur_value > best_value:
				best_value = cur_value
				best_action = a

		return best_action, expanded

	def select_backpropagate(self, board):
		if board.is_terminal():
			return board.get_rewards()[self.play_as]
		best_action, expanded = self.select_action(board)
		board_copy = board.clone()
		board_copy.apply_action(best_action)
		reward = None
		if expanded:
			reward = self.simulate(board_copy)
			self.action_N[(board, best_action)] = 1
			self.N[board] = self.N.get(board, 0) + 1
			self.N[board_copy] = 1
		else:
			reward = self.select_backpropagate(board_copy)
			self.action_N[(board, best_action)] += 1
			self.N[board] += 1

		self.Q[(board, best_action)] =  (self.Q.get((board, best_action), 0) +
										 ((reward - self.Q.get((board, best_action), 0)) / self.action_N[(board, best_action)]))

		return reward

	def choose_best_action(self, board):
		actions = list(board.get_actions())
		return actions[np.argmax([self.Q.get((board, a), 0) for a in actions])]

	def simulate(self, board):
		board_copy = board.clone()
		while not board_copy.is_terminal():
			random_a = random.choice(list(board_copy.get_actions()))
			board_copy.apply_action(random_a)

		return board_copy.get_rewards()[self.play_as]

	def play_action(self, board):
		start_time = time.time()
		while (time.time() - start_time) < self.time_limit:
			self.select_backpropagate(board)

		return self.choose_best_action(board)

if __name__ == '__main__':
	board = ox.Board(8)  # 8x8
	bots = [MCTSBot(0, 0.1), MCTSBot(1, 1.0)]
	# try your bot against itself
	while not board.is_terminal():
		current_player = board.current_player()
		current_player_mark = ox.MARKS_AS_CHAR[ ox.PLAYER_TO_MARK[current_player] ]

		current_bot = bots[current_player]
		a = current_bot.play_action(board)
		board.apply_action(a)

		print(f"{current_player_mark}: {a} -> \n{board}\n")