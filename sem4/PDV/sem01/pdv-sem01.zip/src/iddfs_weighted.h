#pragma once

#include "state.h"

state_ptr iddfs_weighted(state_ptr root);
