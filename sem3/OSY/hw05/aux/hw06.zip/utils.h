#ifndef UTILS_H
#define UTILS_H

#include <string.h>

int find_string_in_array(const char **array, int length, char *what);

#endif //UTILS_H
