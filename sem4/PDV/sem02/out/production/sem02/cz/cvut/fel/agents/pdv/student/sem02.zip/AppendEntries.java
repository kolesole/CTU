package cz.cvut.fel.agents.pdv.student;

import cz.cvut.fel.agents.pdv.dsand.Message;

public class AppendEntries extends Message {
    public int epoch;
    public LogElement committedLogEl;

    public AppendEntries(int epoch, LogElement committedLogEl) {
        this.epoch = epoch;
        this.committedLogEl = committedLogEl;
    }
}
