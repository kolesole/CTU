#include <stdio.h>

int main() {
    printf("Hello world from C-like C++.\n");
}
