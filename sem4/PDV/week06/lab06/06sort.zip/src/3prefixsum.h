#pragma once

#include <cstdlib>
#include <chrono>
#include <iostream>
#include <omp.h>
#include <vector>
#include <cmath>
#include "../pdv_lib/pdv_lib.hpp"

template<typename T>
void prefix_sum_sequential(T* data, const size_t size) {
    for (size_t i = 1; i < size; i++) {
        data[i] += data[i - 1];
    }
}

template<typename T>
void prefix_sum_parallel(T* data, const size_t size) {
    #pragma omp parallel
    {
        // Rozdelte vypocet prefixni sumy pole mezi jednotliva vlakna
        // Zamyslete se, jak byste se mohli "vyhnout" zavislosti sumy
        // na prefixni sume predchazejicich prvku. (Teto zavislosti se
        // nelze vyhnout - ale mozna by nam stacilo "vysbirat" vysledky
        // ostatnich vlaken a nemuseli bychom prochazet cele pole?)
    }
    throw pdv::not_implemented();
}
