from blockworld import BlockWorldEnv
import random
import numpy as np
import time

class QLearning():
	ALPHA = 0.2
	GAMMA = 0.9
	EPSILON = 0.1

	# don't modify the methods' signatures!
	def __init__(self, env: BlockWorldEnv):
		self.env = env
		self.Q = dict()

	def choose_action(self, s):
		actions = s[0].get_actions()
		if random.random() < self.EPSILON:
			return random.choice(actions)
		else:
			return self.get_max_arg_q(s)

	def get_max_q(self, s):
		actions = s[0].get_actions()
		return np.max([self.Q.get((s, a), 0) for a in actions])

	def get_max_arg_q(self, s):
		actions = s[0].get_actions()
		return actions[np.argmax([self.Q.get((s, a), 0) for a in actions])]

	# Q[s] += alpha * (r + gamma * max(Q[s_]) - Q[s])
	def train(self):
		# Use BlockWorldEnv to simulate the environment with reset() and step() methods.
		start_time = time.time()
		for i in range(10000):
			s, _ = self.env.reset()
			while True:
				act = self.choose_action(s)
				key = (s, act)
				s_, r, done, _, _ = env.step(act)

				self.Q[key] = (self.Q.get(key, 0) +
							   self.ALPHA * (r + self.GAMMA * self.get_max_q(s_) - self.Q.get(key, 0)))
				s = s_

				if done:
					break

				elapsed_time = time.time() - start_time
				if elapsed_time > 30:
					return
				# max_err, best_a, done = -np.inf, None, False
				#
				# for a in s[0].get_actions():
				# 	s_, r, done, _, __ = self.env.step(a)
				# 	cur_err = r + self.GAMMA * self.Q.get((s_, 'm'), 0.)
				#
				# 	max_err, best_a = (cur_err, a) if cur_err > max_err else (max_err, best_a)
				# 	if done: break
				#
				# key = (s, best_a)
				# self.Q[key] = self.Q.get(key, 0.) + self.ALPHA * (max_err - self.Q.get((key, 0.)))
				# self.Q[(s, 'm')] = self.Q[key]
				#
				# if done:break

		# s = self.env.reset()
		# s_, r, done = self.env.step(a)

		#pass

	def act(self, s):
		return self.get_max_arg_q(s)
		# random_action = random.choice( s[0].get_actions() )
		# return random_action

if __name__ == '__main__':
	# Here you can test your algorithm. Stick with N <= 4
	N = 4

	env = BlockWorldEnv(N)
	qlearning = QLearning(env)

	# Train
	# print('start training')
	qlearning.train()
	# print('finish training')

	# Evaluate
	test_env = BlockWorldEnv(N)

	test_problems = 10000
	solved = 0
	avg_steps = []

	for test_id in range(test_problems):
		s, _ = test_env.reset()
		done = False

		print(f"\nProblem {test_id}:")
		print(f"{s[0]} -> {s[1]}")

		for step in range(50): 	# max 50 steps per problem
			a = qlearning.act(s)
			s_, r, done, truncated, _ = test_env.step(a)

			print(f"{a}: {s[0]}")

			s = s_

			if done:
				solved += 1
				avg_steps.append(step + 1)
				break

	avg_steps = sum(avg_steps) / len(avg_steps)
	print(f"Solved {solved}/{test_problems} problems, with average number of steps {avg_steps}.")