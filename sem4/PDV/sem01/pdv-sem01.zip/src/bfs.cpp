#include "bfs.h"

// Naimplementujte efektivni algoritmus pro nalezeni nejkratsi cesty v grafu. V teto metode nemusite prilis
// optimalizovat pametove naroky, a vhodnym algoritmem tak muze byt napriklad pouziti prohledavani do sirky
// (breadth-first search).
//
// Funkce ma za ukol vratit ukazatel na cilovy stav, ktery je dosazitelny pomoci nejkratsi cesty.
// Evaluacni kod muze funkci volat opakovane, dejte si pozor, abyste korektne reinicializovali
// globalni promenne, pokud je pouzivate (idealne se jim vyhnete).
state_ptr bfs(state_ptr root) { // NOLINT(*-unnecessary-value-param)
    return root;
}
