#include "workers_list.h"

bool add_worker(char* name, int place) {
    pthread_mutex_lock(&workers_list_mutex);

    worker_t* new_worker = (worker_t*)malloc(sizeof(worker_t));
    if (new_worker == NULL) {
        pthread_mutex_unlock(&workers_list_mutex);
        fprintf(stderr, "Error: Cannot allocate memory for worker!\n");
        return false;
    }

    new_worker->name = strdup(name);
    if (new_worker->name == NULL) {
        fprintf(stderr, "Error: Cannot allocate memory for worker name!\n");
        pthread_mutex_unlock(&workers_list_mutex);
        free(new_worker);
        return false;
    }

    new_worker->end = false;
    new_worker->place = place;
    new_worker->next = NULL;

    if (workers_head == NULL) {
        workers_head = new_worker;
        workers_tail = new_worker;
    } else {
        workers_tail->next = new_worker;
        new_worker->prev = workers_tail;
        workers_tail = new_worker;
    }

    pthread_mutex_unlock(&workers_list_mutex);

    return true;
}

worker_t* find_worker(char* name) {
    worker_t* worker = workers_head;
    while (worker != NULL) {
        if (strcmp(name, worker->name) == 0) {
            return worker;
        }
        worker = worker->next;
    }

    return NULL;
}

void delete_worker(worker_t* worker) {
    pthread_mutex_lock(&workers_list_mutex);

    if (worker == workers_head) {
        if (workers_head != workers_tail) {
            workers_head = workers_head->next;
            workers_head->prev = NULL;
        } else {
            workers_head = NULL;
            workers_tail = NULL;
        }
    }
    else if (worker == workers_tail) {
        workers_tail = workers_tail->prev;
        workers_tail->next = NULL;
    } else {
        worker->next->prev = worker->prev;
        worker->prev->next = worker->next;
    }

    free(worker->name);
    free(worker);

    pthread_mutex_unlock(&workers_list_mutex);
}

void free_list() {
    pthread_mutex_lock(&workers_list_mutex);

    while (workers_head != NULL) {
        worker_t* tmp = workers_head->next;
        free(workers_head->name);
        free(workers_head);
        workers_head = tmp;
    }
    workers_head = NULL;
    workers_tail = NULL;

    pthread_mutex_unlock(&workers_list_mutex);
}

