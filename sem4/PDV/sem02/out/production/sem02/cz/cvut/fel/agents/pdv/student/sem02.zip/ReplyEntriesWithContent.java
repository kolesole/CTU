package cz.cvut.fel.agents.pdv.student;

import cz.cvut.fel.agents.pdv.dsand.Message;

public class ReplyEntriesWithContent extends Message {
    public LogElement committedLogEl;

    public ReplyEntriesWithContent(LogElement committedLogEl) {
        this.committedLogEl = committedLogEl;
    }
}
