#include <omp.h>
#include "../pdv_lib/pdv_lib.hpp"

// V posledni sade uloh se zamerime na vypocet Fibonacciho cisla pomoci rekurze a budete si moci vyzkouset
// `#pragma omp task` pro rekurzivni paralelizaci. V testech pocitame cislo FIB_QUERY, ktere si muzete
// upravit ve funkci `main`.


// sekvencni implementace; je tu jednak pro porovnani rychlosti, a druhak proto, ze i v paralelni
//  implementaci na ni prepneme, kdyz uz mame dost vytvorenych tasku, abychom saturovali vsechna jadra CPU
uint64_t fibonacci_seq(uint64_t n) {
    if (n <= 1) return n;
    return fibonacci_seq(n - 1) + fibonacci_seq(n - 2);
}


uint64_t fibonacci_par(uint64_t n) {
    // TODO: implementujte paralelni vypocet Fibonacciho cisla pomoci `#pragma omp task`
    throw pdv::not_implemented{};
}


int main() {
    constexpr uint64_t FIB_QUERY = 38;

    pdv::benchmark("fibonacci_seq", 10, [&] { return fibonacci_seq(pdv::launder_value(FIB_QUERY)); });
    pdv::benchmark("fibonacci_par", 10, [&] { return fibonacci_par(pdv::launder_value(FIB_QUERY)); });

    return 0;
}
