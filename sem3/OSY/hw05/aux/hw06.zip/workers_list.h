#ifndef WORKERS_LIST_H
#define WORKERS_LIST_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <pthread.h>

#include "worker.h"

extern pthread_mutex_t stdout_mutex;
extern pthread_mutex_t workers_list_mutex;

extern worker_t* workers_head;
extern worker_t* workers_tail;

extern int num_of_workers[7];

bool add_worker(char* name, int place);
worker_t* find_worker(char* name);
void delete_worker(worker_t* worker);
void free_list();

#endif //WORKERS_LIST_H
